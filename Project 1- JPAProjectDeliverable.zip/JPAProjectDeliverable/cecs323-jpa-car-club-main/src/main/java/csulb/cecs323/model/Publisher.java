package csulb.cecs323.model;

import javax.persistence.*;


@Entity (name = "Publishers")
@NamedNativeQueries({
        @NamedNativeQuery(
                name = "ReturnPublisher",
                query = "Select * " +
                        "FROM PUBLISHERS " +
                        "Where PUBLISHERNAME = ?",
                resultClass = Publisher.class
        ),
        @NamedNativeQuery(
                name="AllPublishers",
                query = "SELECT * "+
                        "FROM PUBLISHERS ",
                resultClass = Publisher.class
        ),
        @NamedNativeQuery(
                name="CheckPublisher",
                query = "SELECT * "+
                        "FROM PUBLISHERS "+
                        "WHERE EMAIL = ? "+
                        "OR PUBLISHERNAME = ? "+
                        "OR PHONENUMBER = ?",
                resultClass = Publisher.class
        )
})
/**
 * For holding the contact information and name of a particular book publishing company.
 */
public class Publisher {

    /** The name of the publisher*/
    @Id
    @Column(nullable = false, length = 50)
    private String publisherName;
    /** The email that we can use to contact the publisher*/
    @Column(nullable = false,length = 55, unique = true)
    private String email;
    /** The phone number that we can use to contact the publisher*/
    @Column(nullable = false, length = 20, unique = true)
    private String phoneNumber;

    public Publisher() {}

    /**
     *
     * @param name The publisher's official name.
     * @param email The publisher's official contact email.
     * @param number The publisher's official contact phone number.
     */
    public Publisher(String name, String email, String number)
    {
        publisherName = name;
        this.email = email;
        phoneNumber = number;
    }

    /**
     * gets the name of Publisher Object
     * @return the name of this Publisher Object
     */
    public String getPublisherName()
    {
        return publisherName;
    }

    /**
     * gets the email of Publisher Object
     * @return the email of this Publisher Object
     */
    public String getEmail()
    {
        return email;
    }

    /**
     * gets the phone number of Publisher Object
     * @return the phone number of this Publisher Object
     */
    public String getPhoneNumber()
    {
        return phoneNumber;
    }

    /**
     * changes the name stored in this Object to a new one
     * @param publisherName the updated publisher's name for this  Object
     */
    public void setPublisherName(String publisherName)
    {
        this.publisherName = publisherName;
    }

    /**
     * changes the email stored in this Object to a new one
     * @param email the updated email for this Publisher Object
     */
    public void setEmail(String email)
    {
        this.email = email;
    }

    /**
     * changes the phone number stored in this Object to a new one
     * @param phoneNumber the updated phone number for this Publisher Object
     */
    public void setPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Formats the information stored in Publisher in a user-readable format
     * @return a string formatted as follows:
     *
     * Publisher name:
     * Email:
     * Phone number:
     *
     */
    @Override
    public String toString()
    {
        return "Publisher name: " + this.getPublisherName() + "\nEmail: " + this.getEmail()
                + "\nPhone Number: " + this.getPhoneNumber();
    }

    public boolean equals(Publisher otherPublisher) {
        return publisherName == otherPublisher.getPublisherName() && email == otherPublisher.getEmail()
                && phoneNumber == otherPublisher.getPhoneNumber();
    }
}