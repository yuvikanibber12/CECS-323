package csulb.cecs323.model;

import csulb.cecs323.app.Library;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import java.sql.Array;
import java.util.ArrayList;


@Entity
@NamedNativeQueries({
        @NamedNativeQuery(
                name = "ReturnTeam",
                query = "Select * " +
                        "FROM AUTHORING_ENTITIES " +
                        "Where AUTHORING_ENTITY_TYPE = 'AdHocTeam' AND EMAIL = ?",
                resultClass = AdHocTeam.class
        ),
        @NamedNativeQuery(
                name="AllTeams",
                query = "SELECT * "+
                        "FROM AUTHORING_ENTITIES "+
                        "WHERE AUTHORING_ENTITY_TYPE = 'AdHocTeam'",
                resultClass = AdHocTeam.class
        ),
        @NamedNativeQuery(
                name="ReturnTeamMember",
                query = "SELECT AUTHORING_ENTITIES.* "+
                        "FROM AUTHORING_ENTITIES "+
                        "INNER JOIN AD_HOC_TEAMS_MEMBER AHTM on AUTHORING_ENTITIES.EMAIL = AHTM.INDIVIDUAL_TEAMS_EMAIL "+
                        "WHERE AD_HOC_TEAMS_EMAIL = ? AND "+
                        " INDIVIDUAL_TEAMS_EMAIL = ?",
                resultClass = Individual_Author.class
        ),
        @NamedNativeQuery(
                name="AllTeamMembers",
                query = "SELECT AUTHORING_ENTITIES.* "+
                        "FROM AUTHORING_ENTITIES "+
                        "INNER JOIN AD_HOC_TEAMS_MEMBER AHTM on AUTHORING_ENTITIES.EMAIL = AHTM.INDIVIDUAL_TEAMS_EMAIL "+
                        "WHERE AD_HOC_TEAMS_EMAIL = ? ",
                resultClass = Individual_Author.class
        )
})
/**
 * For holding the contact information and member info of a particular team.
 */
public class AdHocTeam extends Authoring_Entities{
    @ManyToMany(mappedBy = "teams")
    /**
     * holds all of the member authors that this ad hoc team holds.
     */
    private ArrayList<Individual_Author> authors = new ArrayList<Individual_Author>();

    public AdHocTeam()
    {
        this.authoring_entity_type = "AdHocTeam";
    }

    /**
     *
     * @param email The email of the ad hoc team that applies to all members of the team.
     * @param name The name of the ad hoc team.
     */
    public AdHocTeam(String email, String name)
    {
        super(email,name);
        this.authoring_entity_type = "AdHocTeam";
    }

    /**
     *
     * @return All the member authors of this team.
     */
    public ArrayList<Individual_Author> getAuthors (){return authors;}

    /**
     * Adds an individual author to the team as a member, also adds the team to the member's list of teams.
     * @param member individual author to be added to the team.
     * @param em entity manager to handle the addition.
     */
    public void addAuthor(Individual_Author member, EntityManager em){
        authors.add(member);
        member.addTeam(this,em);
        for (Individual_Author a : authors)
            em.persist(a);
        em.flush();
    }

    /**
     * Formats the information stored in AdHocTeam in a user-readable format
     * @return a string formatted as follows:
     *
     * Team Name:
     * Team Email:
     * Team Members:
     * name1 email1
     * name2 email2
     * ...
     */
    @Override
    public String toString()
    {

        String comp = "";
        comp += "Team Name:" + super.getName() + "\nTeam Email:" + super.getEmail();
        comp += "\nTeam Members:";
        for(Authoring_Entities a : authors){
             comp += "\n" +a.toString();
        }
        return comp;

    }


}
