package csulb.cecs323.model;

import javax.persistence.*;
import java.util.List;

@Entity
@NamedNativeQueries({
        @NamedNativeQuery(
                name = "ReturnEntity",
                query = "Select * " +
                        "FROM AUTHORING_ENTITIES " +
                        "Where EMAIL = ?",
                resultClass = Authoring_Entities.class
        ),
        @NamedNativeQuery(
                name="AllEntities",
                query = "SELECT * "+
                        "FROM AUTHORING_ENTITIES ",
                resultClass = Authoring_Entities.class
        )
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "authoring_entity_type", discriminatorType = DiscriminatorType.STRING)
/**
 * For describing a particular authoring entity's contact information and properties
 */
public class Authoring_Entities {
    /**The email of this authoring entity*/
    @Id
    @Column(nullable = false,length = 60)
    private String email;
    /**The type of this authoring entity (individual, group, or team)*/
    @Column(nullable = false,length = 31)
    protected String authoring_entity_type;
    /**The name of this authoring entity*/
    @Column(nullable = false, length = 45)
    private String name;

    /**The books that this authoring entity has written*/
    @OneToMany(mappedBy = "author", cascade = CascadeType.PERSIST)
    private List<Book> books;

    public Authoring_Entities() {}

    /**
     *
     * @param email The email of the Authoring entity at which the writers can be contacted if need be.
     * @param name The name of the individual or group that author a work.
     */
    public Authoring_Entities(String email, String name)
    {
        this.email = email;
        this.name = name;
    }

    /**
     * gets the email of Authoring_Entities Object
     * @return the email of this Authoring_Entities Object
     */
    public String getEmail() {
        return email;
    }

    /**
     * gets the name of Authoring_Entities Object
     * @return the name of this Authoring_Entities Object
     */
    public String getName() {
        return name;
    }

    /**
     * gets the type of Authoring_Entities Object
     * @return the type of this Authoring_Entities Object
     */
    public String getType(){
        return authoring_entity_type;
    }

    /**
     * changes the email stored in this Object to a new one
     * @param email the updated email for this Authoring_Entities Object
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * changes the name stored in this Object to a new one
     * @param name the updated name for this Authoring_Entities Object
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Formats the information stored in Authoring_entities in a user-readable format
     * @return a string formatted as follows:
     *
     * Name:
     * Email:
     *
     */
    @Override
    public String toString()
    {
        return "Name: " + this.getName() + "\nEmail: " + this.getEmail();
    }

    public boolean equals(Authoring_Entities otherAuthoring) {
        return email == otherAuthoring.getEmail() && name == otherAuthoring.getName();
    }
}