package csulb.cecs323.model;

import javax.persistence.*;

@Entity (name = "Books")
@NamedNativeQueries({
        @NamedNativeQuery(
                name = "ReturnBook",
                query = "Select * " +
                        "FROM BOOKS " +
                        "Where ISBN = ?",
                resultClass = Book.class
        ),
        @NamedNativeQuery(
                name="AllBooks",
                query = "SELECT * "+
                        "FROM BOOKS ",
                resultClass = Book.class
        ),
        @NamedNativeQuery(
                name="CheckBook",
                query = "SELECT * "+
                        "FROM BOOKS "+
                        "WHERE (PUBLISHERNAME = ? AND TITLE = ?) "+
                        "OR (AUTHORING_ENTITY_NAME = ? AND TITLE = ?)",
                resultClass = Book.class
        ),
        @NamedNativeQuery(
                name="TitleBooks",
                query = "SELECT * "+
                        "FROM BOOKS "+
                        "WHERE lower(TITLE) LIKE lower(concat('%',concat(?,'%')))",
                resultClass = Book.class
        ),
        @NamedNativeQuery(
                name="TitleBook",
                query = "SELECT * "+
                        "FROM BOOKS "+
                        "WHERE lower(TITLE) = lower(?)",
                resultClass = Book.class
        ),
        @NamedNativeQuery(
                name="CandBook",
                query = "SELECT * "+
                        "FROM BOOKS "+
                        "WHERE TITLE LIKE ? AND AUTHORING_ENTITY_NAME LIKE ? ",
                resultClass = Book.class
        )
})
/**
 * For holding the information about a book. Not for the storage of the information of a physical item.
 */
public class Book {
    /**
     * A unique number associated with the book
     * */
    @Id
    @Column(nullable = false,length = 13)
    private String ISBN;
    /**The name of the book*/
    @Column(nullable = false, length = 50)
    private String title;
    /**The year the book was published */
    @Column(nullable = false)
    private int yearPublished;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "authoring_entity_name",nullable = false)
    private Authoring_Entities author;

    /**The name of the publisher */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "publisherName",nullable = false)
    private Publisher publisher;



    public Book() {}

    /**
     *
     * @param ISBN The International Standard Book Number of the book object.
     *             A standardized, external number used to identify books.
     * @param title The title of the book.
     * @param author The author of the book. Could be an Individual, an ad hoc team, or a writing group
     * @param year The year that the book was published.
     * @param publisher The publisher of the book.
     */
    public Book(String ISBN, String title, Authoring_Entities author, int year, Publisher publisher )
    {
        this.ISBN = ISBN;
        this.title = title;
        this.author = author;
        yearPublished = year;
        this.publisher = publisher;
    }

    /**
     * gets the ISBN of Book Object
     * @return the ISBN of this Book Object
     */
    public String getISBN() {return ISBN;}

    /**
     * gets the Title of Book Object
     * @return the Title of this Book Object
     */
    public String getTitle() { return title; }

    /**
     * gets the Year of publication of Book Object
     * @return the Year of publication of this Book Object
     */
    public int getYearPublished() { return yearPublished; }

    /**
     * gets the Publisher of Book Object
     * @return the Publisher of this Book Object
     */
    public Publisher getPublisher() { return publisher; }

    /**
     * gets the Author of Book Object
     * @return the Author of this Book Object
     */
    public Authoring_Entities getAuthor() {return author;}

    /**
     * changes the ISBN stored in this Object to a new one
     * @param ISBN the updated ISBN for this Book Object
     */
    public void setISBN(String ISBN) {this.ISBN = ISBN;}

    /**
     * changes the title stored in this Object to a new one
     * @param title the updated title for this Book Object
     */
    public void setTitle(String title) {this.title = title;}

    /**
     * changes the year of publication stored in this Object to a new one
     * @param yearPublished the updated year of publication for this Book Object
     */
    public void setYearPublished(int yearPublished) {this.yearPublished = yearPublished;}

    /**
     * changes the publisher stored in this Object to a new one
     * @param publisher the updated  for this Book Object
     */
    public void setPublisher(Publisher publisher) {this.publisher = publisher;}

    /**
     * changes the Author stored in this Object to a new one
     * @param author the updated Author for this Book Object
     */
    public void setAuthor(Authoring_Entities author) {this.author = author;}

    /**
     * Formats the information stored in book in a user-readable format
     * @return a string formatted as follows:
     *
     * Title:
     * Year Published:
     * ISBN:
     * Publisher:
     * Authoring Entity:
     *
     */
    @Override
    public String toString()
    {
        return "Title: " + this.getTitle() + "\nYear Published: " + this.getYearPublished()
                + "\nISBN: " + this.getISBN() + "\nPublisher: " + this.getPublisher().getPublisherName()+"\nAuthoring Entity: "
                + this.getAuthor().toString();
    }

    public boolean equals(Book otherBook) {
        return ISBN == otherBook.getISBN() && title == otherBook.getTitle() && author == otherBook.getAuthor()
                && yearPublished == otherBook.getYearPublished() && publisher == otherBook.getPublisher();
    }
}
