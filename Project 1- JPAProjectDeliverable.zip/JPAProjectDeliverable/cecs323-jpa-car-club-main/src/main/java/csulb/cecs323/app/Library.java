/*
 * Licensed under the Academic Free License (AFL 3.0).
 *     http://opensource.org/licenses/AFL-3.0
 *
 *  This code is distributed to CSULB students in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, other than educational.
 *
 *  2018 Alvaro Monge <alvaro.monge@csulb.edu>
 *
 */

package csulb.cecs323.app;

// Import all of the entity classes that we have written for this application.
import csulb.cecs323.model.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.Scanner;

/**
 * A simple application to demonstrate how to persist an object in JPA.
 * <p>
 * This is for demonstration and educational purposes only.
 * </p>
 * <p>
 *     Originally provided by Dr. Alvaro Monge of CSULB, and subsequently modified by Dave Brown.
 * </p>
 */
public class Library {
   /**
    * You will likely need the entityManager in a great many functions throughout your application.
    * Rather than make this a global variable, we will make it an instance variable within the CarClub
    * class, and create an instance of CarClub in the main.
    */
   private EntityManager entityManager;

   /**
    * The Logger can easily be configured to log to a file, rather than, or in addition to, the console.
    * We use it because it is easy to control how much or how little logging gets done without having to
    * go through the application and comment out/uncomment code and run the risk of introducing a bug.
    * Here also, we want to make sure that the one Logger instance is readily available throughout the
    * application, without resorting to creating a global variable.
    */
   private static final Logger LOGGER = Logger.getLogger(Library.class.getName());

   /**
    * The constructor for the CarClub class.  All that it does is stash the provided EntityManager
    * for use later in the application.
    * @param manager    The EntityManager that we will use.
    */
   public Library(EntityManager manager) {
      this.entityManager = manager;
   }

   public static void main(String[] args) {
      LOGGER.fine("Creating EntityManagerFactory and EntityManager");
      EntityManagerFactory factory = Persistence.createEntityManagerFactory("Library");
      EntityManager manager = factory.createEntityManager();
      // Create an instance of CarClub and store our new EntityManager as an instance variable.
      Library lib = new Library(manager);


      // Any changes to the database need to be done within a transaction.
      // See: https://en.wikibooks.org/wiki/Java_Persistence/Transactions

      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = manager.getTransaction();

      tx.begin();
      // List of owners that I want to persist.  I could just as easily done this with the seed-data.sql
      List <Book> books = new ArrayList<Book>();
      List <Publisher> publishers = new ArrayList<Publisher>();
      List <Authoring_Entities> authoring_entities = new ArrayList<Authoring_Entities>();
      List <Individual_Author> authors  = new ArrayList<Individual_Author>();
      List <WritingGroup> groups                   = new ArrayList<WritingGroup>();
      List <AdHocTeam> teams                       = new ArrayList<AdHocTeam>();

      // Load up my List with the Entities that I want to persist.  Note, this does not put them
      // into the database.


      Scanner sc = new Scanner(System.in);
      int menu_choice;
      do {
         System.out.println(
                 "1. Add new Entry" +
                         "\n2. List information" +
                         "\n3. Delete book" +
                         "\n4. Update book" +
                         "\n5. Get PK's" +
                         "\n6. Exit" +
                         "\nEnter choice:");

         menu_choice = sc.nextInt();

         switch (menu_choice){
            case 1:
               lib.addNew();
               break;
            case 2:
               System.out.println("List Information");
               lib.listInfo();
               break;
            case 3:
               System.out.println("Delete Book");
               lib.deleteBook();
               break;
            case 4:
               System.out.println("Update Book");
               lib.updateBook();
               break;
            case 5:
               System.out.println("Get PK's");
               lib.displayPrimaryKeys();
               break;
            case 6:
               System.out.println("Exit");
               break;
            default:
               System.out.println("Invalid entry");
         }
      } while (menu_choice != 6);

      // Commit the changes so that the new data persists and is visible to other users.
      tx.commit();
      LOGGER.fine("End of Transaction");

   } // End of the main method



   /**
    * Create and persist a list of objects to the database.
    * @param entities   The list of entities to persist.  These can be any object that has been
    *                   properly annotated in JPA and marked as "persistable."  I specifically
    *                   used a Java generic so that I did not have to write this over and over.
    */
   public <E> void createEntity(List <E> entities) {
      for (E next : entities) {
         LOGGER.info("Persisting: " + next);
         // Use the CarClub entityManager instance variable to get our EntityManager.
         this.entityManager.persist(next);
      }

      // The auto generated ID (if present) is not passed in to the constructor since JPA will
      // generate a value.  So the previous for loop will not show a value for the ID.  But
      // now that the Entity has been persisted, JPA has generated the ID and filled that in.
      for (E next : entities) {
         LOGGER.info("Persisted object after flush (non-null id): " + next);
      }
   } // End of createEntity member method


   /**
    * Allows the user to create new Authors, Publishers, and Books
    */
   private void addNew() {
      Scanner sc = new Scanner(System.in);
      int menu_choice;
      System.out.println(
              "1. Add new Authoring Entity" +
                      "\n2. Add new Publisher" +
                      "\n3. Add new Book" +
                      "\n4. Cancel" +
                      "\nEnter choice:");
      menu_choice = sc.nextInt();
      sc.nextLine();
      ArrayList<String> in_vars = new ArrayList<String>();

      switch(menu_choice){
         case 1:
            addAuthoringEntity();
            break;
         case 2:
            System.out.println("Enter Publisher name: ");
            in_vars.add(sc.nextLine());
            System.out.println("Enter Publisher phone number: ");
            in_vars.add(sc.nextLine());
            System.out.println("Enter Publisher email: ");
            in_vars.add(sc.nextLine());
            Publisher testpub = checkPublisher(in_vars.get(0),in_vars.get(2),in_vars.get(1));
            if(testpub != null) {
               if (testpub.getPublisherName() == in_vars.get(0)) {
                  System.out.println("A publisher with the same name already exists.");
               } else if (testpub.getPublisherName() == in_vars.get(1)) {
                  System.out.println("A publisher with the same phone number already exists");
               } else {
                  System.out.println("A publisher with the same email already exists");
               }
               System.out.println("Exiting to main menu.");
               return;
            }
            ArrayList<Publisher> added_pub = new ArrayList<>();
            added_pub.add(new Publisher(in_vars.get(0), in_vars.get(2), in_vars.get(1)));
            createEntity(added_pub);
            this.entityManager.flush();
            break;
         case 3:

            System.out.println("Enter Book ISBN: ");
            String isbn = sc.nextLine();
            if(getBook(isbn) != null){
               System.out.println("A book with this ISBN already exists");
               return;
            }
            System.out.println("Enter Book title: ");
            String title = sc.nextLine();
            Publisher user_pub = getUserPub();
            if (user_pub == null) {
               System.out.println("No available publishers stored");
               return;
            }
            Authoring_Entities user_author = getUserEntity();
            if(user_author == null){
               System.out.println("No available authoring entities stored");
               return;
            }
            Book test_book = checkBook(title,user_pub.getPublisherName(),user_author.getName());
            if (test_book != null){
               if (user_pub.getPublisherName() == test_book.getPublisher().getPublisherName()){
                  System.out.println("This publisher has already released a book with this title.");
               }
               else{
                  System.out.println("An author with this name has already released a book with this title.");
               }
               return;
            }
            System.out.println("Enter Book year: ");
            int year = Integer.parseInt(sc.nextLine());
            ArrayList<Book> added_book = new ArrayList<>();
            added_book.add(new Book(isbn, title, user_author,year, user_pub));
            createEntity(added_book);
            this.entityManager.flush();
            break;
         case 4:
            break;
         default:
      }

   }

   /**
    * Allows users to create new Authoring Entities
    */
   private void addAuthoringEntity(){
      Scanner sc = new Scanner(System.in);
      String menu_choice;
      System.out.println(
              "1. Add new Writing Group" +
                      "\n2. Add new Author" +
                      "\n3. Add new Ad Hoc Team" +
                      "\n4. Add an Author to an existing Ad Hoc Team" +
                      "\n5. Cancel" +
                      "\nEnter choice:");
      ArrayList<Authoring_Entities> added = new ArrayList<Authoring_Entities>();
      menu_choice = sc.nextLine();
      String entity_name;
      String entity_email;
      String head;
      int year;
      switch(menu_choice){
         case "1":
            System.out.print("Enter Group Email: ");
            entity_email = sc.nextLine();
            if(!checkEmail(entity_email)){
               System.out.println("Error: a group with that email already exists. Exiting to main menu.");
               return;
            }
            System.out.print("Enter Group Name: ");
            entity_name = sc.nextLine();
            System.out.print("Enter Group Head Writer: ");
            head = sc.nextLine();
            System.out.print("Enter Group Year: ");
            year = sc.nextInt();
            sc.nextLine();
            added.add(new WritingGroup(entity_email, entity_name, head, year));
            System.out.println("Are you sure you want to add Group: ");
            System.out.println(added);
            System.out.println("Enter Y to confirm: ");
            if(sc.nextLine().toLowerCase().contains("y")){
               this.entityManager.persist(new WritingGroup(entity_email, entity_name, head, year));
               this.entityManager.flush();
            }

            break;
         case "2":
            Individual_Author newAuthor = createIndividualAuthor();
            added.add(newAuthor);
            if(!checkEmail(newAuthor.getEmail())){
               System.out.println("Error: an author with that email already exists. Exiting to main menu.");
               return;
            }
            System.out.println("Are you sure you want to add Author: ");
            System.out.println(added);
            System.out.println("Enter Y to confirm: ");
            if(sc.nextLine().toLowerCase().contains("y")){
               this.entityManager.persist(newAuthor);
               this.entityManager.flush();
            }
            break;
         case "3":
            System.out.print("Enter Team Email: ");
            entity_email = sc.nextLine();
            if(!checkEmail(entity_email)){
               System.out.println("Error: a team with that email already exists. Exiting to main menu.");
               return;
            }
            System.out.print("Enter Team Name: ");
            entity_name = sc.nextLine();
            System.out.println("Create New Author: ");
            Individual_Author ind = getUserAuthor();
            if(ind == null){
               System.out.println("No available individual authors stored");
               return;
            }
            AdHocTeam newTeam = new AdHocTeam(entity_email,entity_name);
            System.out.println("Are you sure you want to add Team: ");
            System.out.println(newTeam);
            System.out.println(ind);
            System.out.println("Enter Y to confirm: ");
            if(sc.nextLine().toLowerCase().contains("y")){
               newTeam.addAuthor(ind,this.entityManager);
               this.entityManager.persist(newTeam);
               this.entityManager.flush();
            }
            break;
         case "4":
            Individual_Author user_author = getUserAuthor();
            if(user_author == null){
               System.out.println("No available individual authors stored");
               return;
            }
            AdHocTeam user_team = getUserTeam();
            if(user_team == null){
               System.out.println("No available teams stored");
               return;
            }
            if(getTeamMember(user_team.getEmail(),user_author.getEmail()) != null && !checkEmail(user_team.getEmail()) ){
               System.out.println("Error: a team with that email already exists. Exiting to main menu.");
               return;
            }
            System.out.println("Are you sure you want to add Author: ");
            System.out.println(user_author);
            System.out.println("To team: ");
            System.out.println(user_team);
            System.out.println("Enter Y to confirm: ");
            if(sc.nextLine().toLowerCase().contains("y")){
               user_team.addAuthor(user_author,this.entityManager);
               added.add(user_author);
               added.add(user_team);
               createEntity(added);
               this.entityManager.flush();
            }
            break;
         case "5":
            System.out.println("Cancelling. Moving back to main menu.");
            break;
         default:
            System.out.println("Invalid input. Moving back to main menu.");
      }
   }// End of addAuthoringEntity member method

   /**
    * Allows users to choose to display the information of either a publisher,book, or writing book
    */
   private void listInfo(){
      Scanner sc = new Scanner(System.in);
      int menu_choice;
      System.out.println(
              "1. Get Publisher info" +
                      "\n2. Get Book info" +
                      "\n3. Get Writing Group info" +
                      "\n4. Cancel" +
                      "\nEnter choice:");
      menu_choice = sc.nextInt();
      sc.nextLine();
      switch(menu_choice){
         case 1:
            Publisher user_pub = getUserPub();
            if(user_pub == null){
               System.out.println("No available publishers stored");
               return;
            }
            System.out.println(user_pub);
            break;
         case 2:
            Book user_book = getUserBook();
            if(user_book == null){
               System.out.println("No available books stored");
               return;
            }
            System.out.println(user_book);
            System.out.println(user_book.getAuthor());
            System.out.println(user_book.getPublisher());
            break;
         case 3:
            WritingGroup user_group = getUserGroup();
            if(user_group == null){
               System.out.println("No available writing groups stored");
               return;
            }
            System.out.println(user_group);
            break;
         case 4:
            break;
         default:
      }
   }

   /**
    * gets list of books based on user input
    *
    * @return a list of the books with a certain title and author
    */
   private List<Book> getCandBook(){
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter title: ");
      String title = sc.nextLine();
      System.out.println("Enter email of Author: ");
      String author = sc.nextLine();
      return this.entityManager.createNamedQuery("CandBook",Book.class)
              .setParameter(1,title).setParameter(2,author).getResultList();
   }

   /**
    * Deletes a book from the database
    */
   private void deleteBook(){
      displayBooks();
      List<Book> out = getCandBook();
      if (out.size() == 0){
         System.out.println("No such book exists");
      }
      else{
         System.out.println("Deleting Book");
         System.out.println(out.get(0));
         entityManager.remove(out.get(0));
      }
   }


   /**
    * this method gets a author based on user input
    *
    * @return the a user specified author from the database
    */
   private Individual_Author getUserAuthor(){
      Scanner sc = new Scanner(System.in);
      Individual_Author out;
      List<Individual_Author> available = this.entityManager.createNamedQuery("AllAuthors",
              Individual_Author.class).getResultList();
      if (available.isEmpty())
         return null;
      do {
         System.out.println("\nAvailable Authors:");
         for (Individual_Author a : available) {
            System.out.println(String.format("%s: %s", a.getEmail(), a.getName()));
         }
         System.out.print("\nEnter Author Email from list: ");
         out = getAuthor(sc.nextLine());
      } while(out == null);
      return out;
   }

   /**
    * this method gets a author based on email
    *
    * @param email enter an email of an author
    * @return returns an author object that is specified by the email
    */
   private Individual_Author getAuthor(String email){
      List<Individual_Author> out = this.entityManager.createNamedQuery("ReturnAuthor",
              Individual_Author.class).setParameter(1,email).getResultList();
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }

   /**
    * this method gets a team based on user input
    *
    * @return adgoc team that is returned by the user
    */
   private AdHocTeam getUserTeam(){
      Scanner sc = new Scanner(System.in);
      AdHocTeam out;
      List<AdHocTeam> available = this.entityManager.createNamedQuery("AllTeams",
              AdHocTeam.class).getResultList();
      if (available.isEmpty())
         return null;
      do {
         System.out.println("\nAvailable Teams:");
         for (AdHocTeam a : available) {
            System.out.println(String.format("%s: %s", a.getEmail(), a.getName()));
         }
         System.out.print("\nEnter Author Email from list: ");
         out = getTeam(sc.nextLine());
      } while(out == null);
      return out;
   }

   /**
    * this method gets a team based on an email inputted
    *
    * @param email inputs the email of a team user want to retrieve
    * @return the team object from the email user enters
    */
   private AdHocTeam getTeam(String email){
      List<AdHocTeam> out = this.entityManager.createNamedQuery("ReturnTeam",
              AdHocTeam.class).setParameter(1,email).getResultList();
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }

   /**
    * returns writing group based on user inputs
    *
    * @return returns the writing group from a user specified choice
    */
   private WritingGroup getUserGroup(){
      Scanner sc = new Scanner(System.in);
      WritingGroup out;
      List<WritingGroup> available = this.entityManager.createNamedQuery("AllGroups",
              WritingGroup.class).getResultList();
      if (available.isEmpty())
         return null;
      do {
         System.out.println("\nAvailable Groups:");
         for (WritingGroup a : available) {
            System.out.println(String.format("%s: %s", a.getEmail(), a.getName()));
         }
         System.out.print("\nEnter Author Email from list: ");
         out = getGroup(sc.nextLine());
      } while(out == null);
      return out;
   }

   /**
    * returns writing group based on email inputterd
    *
    * @param email enter group email the user wants to retrieve
    * @return group based on the email entered
    */
   private WritingGroup getGroup(String email){
      List<WritingGroup> out = this.entityManager.createNamedQuery("ReturnGroup",
              WritingGroup.class).setParameter(1,email).getResultList();
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }

   /**
    *
    * checks if mail is used in author db
    *
    * @param email checks if email exists in the author database
    * @return if the email is valid
    */
   private boolean checkEmail(String email){
      List<Authoring_Entities> out = this.entityManager.createNamedQuery("ReturnEntity",
              Authoring_Entities.class).setParameter(1,email).getResultList();

      return out.size() == 0 ;
   }

   /**
    * returns individual author based on team mail and member mails
    *
    * @param team_mail enter teams email that you would like to retrieve author from
    * @param member_mail enter individual authors email you would like to retrieve
    * @return individual author from team based on inputs
    */
   private Individual_Author getTeamMember(String team_mail, String member_mail) {
      List<Individual_Author> out = this.entityManager.createNamedQuery("ReturnTeamMember",
              Individual_Author.class).setParameter(1,team_mail).setParameter(2,member_mail).getResultList();
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }

   /**
    * returns Publisher based on name,email,phone
    *
    * @param name enter publisher name
    * @param email enter publisher email
    * @param phone enter publisher phone number
    * @return publisher object based on past queries
    */
   private Publisher checkPublisher(String name, String email, String phone){
      List<Publisher> out = this.entityManager.createNamedQuery("CheckPublisher",
                      Publisher.class).setParameter(1,email).setParameter(2,name)
              .setParameter(3,phone).getResultList();
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }

   /**
    * returns authoring entity based on user input
    *
    * @return Author Entity based on user inputs
    */
   private Authoring_Entities getUserEntity(){
      Scanner sc = new Scanner(System.in);
      Authoring_Entities out;
      List<Authoring_Entities> available = this.entityManager.createNamedQuery("AllEntities",
              Authoring_Entities.class).getResultList();
      if (available.isEmpty())
         return null;
      do {
         System.out.println("\nSelect An Authoring Entity.\nAvailable Entities:");
         for (Authoring_Entities a : available) {
            System.out.println(String.format("%s: %s", a.getEmail(), a.getName()));
         }
         System.out.print("\nEnter Email from list: ");
         out = getEntity(sc.nextLine());
      } while(out == null);

      return out;
   }

   /**
    * retrieves authoring entity based on email
    *
    * @param email input email of entity you would like to retrieve
    * @return authoring entity object based on user email
    */
   private Authoring_Entities getEntity(String email){
      List<Authoring_Entities> out = this.entityManager.createNamedQuery("ReturnEntity",
              Authoring_Entities.class).setParameter(1,email).getResultList();
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }

   /**
    * retrieves publusher based on user input
    *
    * @return Publisher based on user input
    */
   private Publisher getUserPub(){
      Scanner sc = new Scanner(System.in);
      Publisher out;
      List<Publisher> available = this.entityManager.createNamedQuery("AllPublishers",
              Publisher.class).getResultList();
      if (available.isEmpty())
         return null;
      do {
         System.out.println("\nAvailable Entities:");
         for (Publisher a : available) {
            System.out.println(String.format("%s", a.getPublisherName()));
         }
         System.out.print("\nEnter Name from list: ");
         out = getPub(sc.nextLine());
      } while(out == null);

      return out;
   }

   /**
    * retrieve publisher based on name
    *
    * @param in_name name of a publisher you would like to retrieve
    * @return publisher object based on inputted string
    */
   private Publisher getPub(String in_name){
      List<Publisher> out = this.entityManager.createNamedQuery("ReturnPublisher",
              Publisher.class).setParameter(1,in_name).getResultList();
      //System.out.println(out);
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }

   /**
    * retrieve book based on user input
    *
    * @return book object based on user input
    */
   private Book getUserBook(){
      Scanner sc = new Scanner(System.in);
      Book out;
      List<Book> available = this.entityManager.createNamedQuery("AllBooks",
              Book.class).getResultList();
      if (available.isEmpty())
         return null;
      do {
         System.out.println("\nAvailable Entities:");
         for (Book a : available) {
            System.out.println(String.format("%s: %s, by: %s", a.getISBN(), a.getTitle(), a.getAuthor().getName()));
         }
         System.out.print("\nEnter ISBN from list: ");
         out = getBook(sc.nextLine());
      } while(out == null);

      return out;
   }

   /**
    * retrieves book from existing book
    *
    * @param ISBN input isbn of a book you would like to retrieve
    * @return book object returned based on isbn
    */
   private Book getBook(String ISBN){
      List<Book> out = this.entityManager.createNamedQuery("ReturnBook",
              Book.class).setParameter(1,ISBN).getResultList();
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }

   /**
    * checks if book exists in database
    *
    * @param title title of book you would like to retrieve
    * @param name name of book you would like to retrieve
    * @param publisher name of published you would like to retrieve
    * @return Book object if it exists
    */
   private Book checkBook(String title, String name, String publisher){
      List<Book> out = this.entityManager.createNamedQuery("CheckBook",
                      Book.class).setParameter(1,publisher).setParameter(2,title)
              .setParameter(3,name).setParameter(4,title).getResultList();
      if(out.size() == 0){
         return null;
      }
      else {
         return out.get(0);
      }
   }
   private void displayBooks(){
      List<Book> out = this.entityManager.createNamedQuery("AllBooks",Book.class)
              .getResultList();

      for(Book b: out){
         System.out.printf("%s: %s ,by: %s%n", b.getISBN(), b.getTitle(), b.getAuthor().getEmail());
      }
   }
   private void updateBook() {
      displayBooks();
      List<Book> out = getCandBook();
      if (out.size() == 0){
         System.out.println("No such book exists");
      }
      else{
         ArrayList<Book> added_book = new ArrayList<>();
         System.out.println("Updating Book!");
         Book a = out.get(0);
         System.out.println(a);
         System.out.println("Enter New Authoring Entity: ");
         a.setAuthor(getUserEntity());
         added_book.add(a);
         entityManager.remove(out.get(0));
         createEntity(added_book);
         this.entityManager.flush();
      }
   }

   /**
    * displays primary keys
    */
   public void displayPrimaryKeys(){
      List<Book> bookList =
              this.entityManager.createNamedQuery("AllBooks", Book.class).getResultList();
      List<Publisher> publisherList =
              this.entityManager.createNamedQuery("AllPublishers", Publisher.class).getResultList();
      List<Authoring_Entities> authoringEntitiesList =
              this.entityManager.createNamedQuery("AllEntities", Authoring_Entities.class).getResultList();
      System.out.println("Book Primary Keys\n");
      if(!bookList.isEmpty()) {
         for ( Book b : bookList) {
            System.out.println("ISBN: "+b.getISBN());
         }
      }
      else{
         System.out.println("Records of Books does not exist.");
      }

      System.out.println("\nPublisher Primary Keys\n");
      if(!publisherList.isEmpty()) {
         for (Publisher p : publisherList) {
            System.out.println("NAME: "+ p.getPublisherName());
         }
      }
      else{
         System.out.println("There are no Publishers in DB..");
      }

      System.out.println("\nAuthoring Entities Primary Keys\n");
      if(!authoringEntitiesList.isEmpty()) {
         for (Authoring_Entities author : authoringEntitiesList) {
            System.out.println("Type:"+ author.getType()+"   "+ author);

         }
      }
      else{
         System.out.println("Records of Publishers does not exist.");
      }
   }

   /**
    * @return returns author based on user input
    */
   public Individual_Author createIndividualAuthor(){
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter Author Email: ");
      String email = sc.nextLine();
      System.out.print("Enter Author Name: ");
      String name = sc.nextLine();
      return new Individual_Author(email,name);
   }

}


