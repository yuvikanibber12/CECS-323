package csulb.cecs323.model;

import javax.persistence.*;
import java.util.ArrayList;


@Entity
@NamedNativeQueries({
        @NamedNativeQuery(
                name = "ReturnAuthor",
                query = "Select * " +
                        "FROM AUTHORING_ENTITIES " +
                        "Where AUTHORING_ENTITY_TYPE = 'Individual_Author' AND EMAIL = ?",
                resultClass = Individual_Author.class
        ),
        @NamedNativeQuery(
                name="AllAuthors",
                query = "SELECT * "+
                        "FROM AUTHORING_ENTITIES "+
                        "WHERE AUTHORING_ENTITY_TYPE = 'Individual_Author'",
                resultClass = Individual_Author.class
        )
})
/**
 * For holding the basic contact and name of a single author.
 */
public class Individual_Author extends Authoring_Entities{
    @ManyToMany
    @JoinTable(
            name = "Ad_Hoc_teams_member",
            joinColumns = @JoinColumn(name = "individual_teams_email",referencedColumnName = "email"),
            inverseJoinColumns = @JoinColumn(name = "ad_hoc_teams_email",referencedColumnName = "email")
    )
    /**
     * Holds all of the ad hoc teams that this author is a part of.
     */
    private ArrayList<AdHocTeam> teams = new ArrayList<AdHocTeam>();

    public Individual_Author()
    {
        this.authoring_entity_type = "Individual_Author";
    }

    /**
     *
     * @param email the email of this particular author.
     * @param name This Author's used name.
     */
    public Individual_Author(String email, String name)
    {
        super(email,name);
        this.authoring_entity_type = "Individual_Author";
    }
    /**
     *
     * @return All the teams this author is a part of.
     */
    public ArrayList<AdHocTeam> getTeams(){ return teams;}

    /**
     * Adds another team that the Author is a part of.
     * @param team team to be added to the author's record.
     * @param em entity manager to handle the addition.
     */
    public void addTeam(AdHocTeam team, EntityManager em){
        teams.add(team);
        for (AdHocTeam t : teams)
            em.persist(t);
        em.flush();
    }

    /**
     * Formats the information stored in Individual_Author in a user-readable format to be added to other functions
     * @return a string formatted as follows:
     *
     * name email
     */
    @Override
    public String toString() {
        //gotta deal with authors not being in team
        return super.getName() +" "+super.getEmail();
    }

    public boolean equals(Individual_Author otherAuthor) {
        return super.equals(otherAuthor) && teams.equals(otherAuthor.getTeams());
    }


}
