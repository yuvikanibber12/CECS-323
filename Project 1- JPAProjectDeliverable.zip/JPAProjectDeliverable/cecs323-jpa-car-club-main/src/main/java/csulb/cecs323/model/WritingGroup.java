package csulb.cecs323.model;

import javax.persistence.*;

@Entity
@NamedNativeQueries({
        @NamedNativeQuery(
                name = "ReturnGroup",
                query = "Select * " +
                        "FROM AUTHORING_ENTITIES " +
                        "Where AUTHORING_ENTITY_TYPE = 'WritingGroup' AND EMAIL = ?",
                resultClass = WritingGroup.class
        ),
        @NamedNativeQuery(
                name="AllGroups",
                query = "SELECT * "+
                        "FROM AUTHORING_ENTITIES "+
                        "WHERE AUTHORING_ENTITY_TYPE = 'WritingGroup'",
                resultClass = WritingGroup.class
        )
})
/**
 * For holding information of a particular writing group, though not its members, only its most prominent information.
 */
public class WritingGroup extends Authoring_Entities{
    /**The name of the head writer of this group*/
    @Id
    @Column(length = 60)
    private String headWriter;
    /**The year that this writing group was formed*/
    @Id
    @Column
    private int yearFormed;

    public WritingGroup(){
        super();
        this.authoring_entity_type = "WritingGroup";
    }

    /**
     *
     * @param email The contact email of this group.
     * @param name The name of this group.
     * @param headWriter The full name of the head writer of this group.
     * @param yearFormed The year that this group was formed.
     */
    public WritingGroup(String email, String name, String headWriter, int yearFormed){
        super(email,name);
        this.headWriter = headWriter;
        this.yearFormed = yearFormed;
        this.authoring_entity_type = "WritingGroup";
    }

    /**
     * gets the name of the head writer of WritingGroup Object
     * @return the name of the head writer of this WritingGroup Object
     */
    public String getHeadWriter() { return headWriter;}

    /**
     * gets the year the group was formed of WritingGroup Object
     * @return the year the group was formed of this WritingGroup Object
     */
    public int getYearFormed() {return yearFormed;}

    /**
     * changes the full name of the head writer stored in this Object to a new one
     * @param headWriter the updated full name of the head writer for this WritingGroup Object
     */
    public void setHeadWriter(String headWriter) {this.headWriter = headWriter;}

    /**
     * changes the year the group was formed stored in this Object to a new one
     * @param yearFormed the updated year the group was formed for this WritingGroup Object
     */
    public void setYearFormed(int yearFormed) {this.yearFormed = yearFormed;}

    /**
     * Formats the information stored in WritingGroup in a user-readable format
     * @return a string formatted as follows:
     *
     * Name:
     * Email:
     * Head Writer:
     * Year formed:
     */
    @Override
    public String toString() {
        return super.toString() + "\nHead Writer: " + this.getHeadWriter() + "\nYear formed: " + this.getYearFormed();
    }



    public boolean equals(WritingGroup otherWritingGroup) {
        if (this.getYearFormed() == otherWritingGroup.getYearFormed()
                && this.getHeadWriter() == otherWritingGroup.getHeadWriter()) {
            return true;
        }
        return false;
    }
}
