# cecs323-jpa-dbapp
Java database application using JPA
